# Handoff: Dashboard quản lý MikroTik

## Overview
Dashboard quản trị nhiều thiết bị MikroTik theo mô hình đa tenant (nhà cung cấp → công ty/đại lý → chi nhánh). Chức năng chính: quản lý thiết bị MikroTik (WAN/Ethernet/CPU/RAM monitor), quản lý user PPPoE/Hotspot (gán vào NAS + RADIUS), tạo & gán gói cước, RADIUS/AAA, VPN ZeroTier để truy cập thiết bị sau NAT, phân tích dữ liệu người dùng, hoá đơn theo tenant.

## About the Design Files
File trong bundle này (`MikroTik Manager.dc.html`) là **thiết kế tham khảo dạng HTML** — mô phỏng giao diện và hành vi dự kiến, không phải code sản phẩm để copy trực tiếp. Toàn bộ dữ liệu là dữ liệu mẫu (mock), không có backend/API thật, không có RouterOS API/RADIUS server/ZeroTier controller thật phía sau. Nhiệm vụ là **dựng lại thiết kế này trong môi trường thực tế của dự án** (framework FE do dev chọn — React/Vue/Flutter web, v.v. — kết hợp backend gọi RouterOS API, FreeRADIUS, ZeroTier Central API), dùng pattern/thư viện sẵn có của codebase nếu có.

## Fidelity
**High-fidelity**: màu sắc, khoảng cách, typography, layout trong file là chủ đích thiết kế cuối, nên tái tạo pixel-gần-đúng. Dữ liệu và một số hành vi (thanh toán, đồng bộ RouterOS...) chỉ là mô phỏng phía client, cần thay bằng logic thật.

## Kiến trúc điều hướng
Sidebar trái cố định (nền `#1b1f23`), chia 3 nhóm:
- **VẬN HÀNH**: Tổng quan, Thiết bị MikroTik (badge đỏ = số thiết bị lỗi)
- **KHÁCH HÀNG**: Người dùng, Phân tích dữ liệu
- **GÓI & HẠ TẦNG**: Gói cước, Gán gói hàng loạt, RADIUS/AAA, VPN ZeroTier
- **TỔ CHỨC**: Tenant & phân cấp, Hoá đơn

Header trên cùng có: breadcrumb + tiêu đề màn hình, ô tìm kiếm, nút Đồng bộ, nút "+ Gán gói", và **bộ chuyển phạm vi (tenant scope switcher)** — dropdown chọn tenant, mọi bảng/KPI trong toàn app lọc theo tenant đang chọn (kể cả tenant con).

## Màn hình

### 1. Tổng quan (Overview)
- 5 KPI card: thiết bị online, user online, thuê bao hoạt động, sắp hết hạn 7 ngày, doanh thu tháng
- Danh sách "Lượng data theo từng thiết bị 24h" — thanh ngang, sort theo lượng cao nhất, click mở chi tiết router
- 2 cột: "Thiết bị tải cao nhất" (bảng, click mở chi tiết) và "Cảnh báo" (list, dot màu theo mức độ)
- Toggle tweak `showTrafficChart` ẩn/hiện khối biểu đồ

### 2. Thiết bị MikroTik (Router list)
- Filter chip: Tất cả/Online/Có vấn đề/Tải cao
- Nút "+ Thêm thiết bị" → modal nhập tên, IP, model, site, API username/password, chọn tenant (list cây phân cấp)
- Bảng: tên+IP, model, RouterOS version, uptime, CPU%, RAM%, user online, trạng thái (badge màu), cột Thao tác (nút "Xem" mở chi tiết, nút "Dừng"/"Bật lại" toggle trạng thái stopped cục bộ)
- Phân trang 12 dòng/trang, bảng cao full màn hình (header sticky, footer phân trang cố định, phần giữa tự cuộn)

### 3. Chi tiết thiết bị (Router detail)
- Breadcrumb quay lại, KPI uptime/CPU/RAM/user online
- Bảng WAN: interface, IP công khai, RX/TX Mbps, trạng thái (UP/STANDBY/DOWN), mini sparkline 60 phút
- Bảng Ethernet: interface, IP, RX/TX, trạng thái, thanh tải %
- Biểu đồ "Lượng data sử dụng 24h" (area+line chart SVG)
- "Data dùng nhiều nhất trên thiết bị" — top user theo GB, so với trung bình gói

### 4. Người dùng (Users)
- Tab Hoạt động/Ngưng hoạt động/Tất cả
- Filter chip: Tất cả/PPPoE/Hotspot/Cần xử lý
- Nút "+ Thêm user" → modal username/password, loại (PPPoE/Hotspot), chọn MikroTik + gói cước
- Nút "⇪ Nhập Excel hàng loạt" → modal: mô tả cột file (username/password/loại/MikroTik/gói), tải file mẫu, dropzone .xlsx/.csv
- Bảng: checkbox chọn nhiều, username+MAC (click mở chi tiết user), loại, thiết bị, gói cước, thanh quota data dùng, hết hạn, trạng thái, cột Thao tác (Chi tiết/Gia hạn/Nạp data/Tạm ngưng)
- Phân trang 15 dòng/trang, full-height giống bảng router
- Nút "Đổi gói cho mục đã chọn" → sang màn Gán gói hàng loạt với các dòng đã chọn giữ nguyên

### 5. Chi tiết user (User detail)
- KPI: gói cước hiện tại, **Data đã dùng** (card lớn 2 cột: số GB dùng + % dùng, thanh progress, ghi chú còn lại bao nhiêu GB, nút "Mua thêm" +5/+10/+20 GB), hết hạn, giá gói
- Modal xác nhận thanh toán khi bấm mua thêm data — chỉ cộng GB sau khi bấm "Thanh toán & cộng data" (không cộng ngay khi bấm gói)
- Biểu đồ cột data 14 ngày gần nhất
- "Top trang web truy cập" (domain, category, GB, thanh %) + "Phân loại lưu lượng theo nội dung" (video/mạng xã hội/mua sắm/...)
- Bảng "Lịch sử phiên RADIUS" (thời gian, thời lượng, data, NAS)
- Bảng "Lịch sử thanh toán" (thời gian, nội dung, số tiền, trạng thái thành công/thất bại)

### 6. Gói cước (Packages)
- Bảng profile: tên, rate-limit, quota GB (không còn gói "không giới hạn"), thời hạn, giá/tháng, số device đồng thời, số đang dùng — click chọn để sửa
- Panel sửa bên phải: tên, down/up Mbps, **THỜI HẠN chọn 2 bước** (đơn vị Ngày/Tháng → rồi mốc cụ thể: 1/3/7/15 ngày hoặc 1/3/6/12 tháng), quota GB + số device, giá, preview lệnh CLI RouterOS, nút Lưu & đẩy xuống thiết bị

### 7. Gán gói hàng loạt (Bulk assign) — 4 bước
1. Chọn user (checkbox, chọn tất cả/bỏ chọn)
2. Chọn MikroTik/NAS (radio, để trống = giữ nguyên thiết bị hiện tại của mỗi user)
3. Chọn gói cước (radio card)
4. Xác nhận: tóm tắt số user/gói/thiết bị/chênh lệch doanh thu, preview lệnh CLI RADIUS CoA, checkbox "ngắt kết nối hiện tại", nút áp dụng

### 8. RADIUS / AAA
- KPI: auth/phút, reject/giờ, session đang mở, NAS đang báo cáo, CoA/DM đã gửi
- 4 tab: **Client NAS** (bảng NAS/tenant/shared secret/cổng 1812-1813/CoA/session/trạng thái), **Session đang mở** (username/NAS/Framed-IP/thời lượng/in-out/nút ngắt phiên), **Accounting** (log live: ACCESS-ACCEPT/REJECT, CoA-ACK, ACCT-INTERIM...), **Chính sách** (ràng buộc realm theo tenant, quota cứng, CoA khi đổi gói, fallback khi mất AAA — card có toggle bật/tắt)

### 9. VPN ZeroTier
- 4 KPI: mạng trong phạm vi, node online, chờ duyệt, đi qua relay
- Layout 2 cột: sidebar trái danh sách mạng (dot xanh/đỏ theo có pending không), phải: thanh info mạng đang chọn (CIDR/thành viên/tenant + nút Duyệt N yêu cầu) và 3 tab: **Thành viên** (node/vai trò/IP ảo/latency/uỷ quyền/kết nối), **Định tuyến** (managed routes cho Winbox/SSH qua NAT), **Flow rules** (ACL dạng rule text)

### 10. Phân tích dữ liệu (Analytics)
- Filter khoảng thời gian 7/30/90 ngày/12 tháng
- KPI: ARPU, churn tháng, data TB/user, phiên TB/ngày, user vượt quota
- Chart tăng trưởng thuê bao 12 tháng (cột mới/rời mạng), phân bổ theo gói (thanh %)
- Heatmap mật độ sử dụng theo giờ (7 ngày × 24h)
- Top thuê bao ngốn băng thông, vòng đời thuê bao (funnel), nâng/hạ gói, gợi ý hành động (insight card)

### 11. Tenant & phân cấp
- Cây tổ chức 3 cấp: Nhà cung cấp → Công ty/Đại lý → Chi nhánh/Đại lý con — bảng lồng cấp bằng indent, hiện router/user/quota/doanh thu/quyền
- Bảng tài khoản quản trị theo phạm vi (vai trò SUPERADMIN/TENANT ADMIN/OPERATOR/RESELLER, 2FA)
- Panel bên phải: **Thông tin khách hàng** (người đại diện, điện thoại, email, địa chỉ, mã số thuế, khách hàng từ), thống kê tenant, nút "Chuyển sang phạm vi này", khối kế thừa gói cước (RIÊNG/KẾ THỪA từ tenant cha), ma trận quyền theo cấp (checkbox on/off)

### 12. Hoá đơn (Invoices)
- KPI: tổng hoá đơn tháng, đã thu, chưa thu, quá hạn
- Filter trạng thái, bảng hoá đơn theo tenant trong phạm vi (mã hoá đơn, tenant, kỳ, số tiền, hạn thanh toán, trạng thái)

## Design Tokens
- **Màu nền**: `#eef0f2` (page), `#fff` (card), sidebar `#1b1f23`
- **Màu nhấn (accent)**: `#12a594` (teal), hover đậm `#0f8175`, chữ trên nền accent `#04211e`
- **Trạng thái**: xanh thành công `#e6f5f3`/`#0b5f56`, vàng cảnh báo `#fdf3e2`/`#8a5a11`, đỏ lỗi `#fdecec`/`#a52327` hoặc `#c0292d`, xám trung tính `#eef0f2`/`#5a636b`
- **Chữ**: `#16191c` (chính), `#4b545c` (phụ), `#7c858d`/`#8e99a3`/`#9aa2a9` (mờ dần)
- **Border**: `#dfe3e6` (card), `#eaedef`/`#f2f4f5` (chia dòng bảng)
- **Font**: IBM Plex Sans (chữ UI), IBM Plex Mono (số liệu, mã, badge) — cả 2 tải qua Google Fonts, weight 400/500/600/700
- **Cỡ chữ**: 22px (KPI số lớn), 14-15px (tiêu đề), 12-13px (nội dung bảng), 9.5-11px (label/mono nhỏ)
- **Border-radius**: 6-8px (card/button/input), 3-4px (badge), pill/circle cho dot trạng thái
- **Spacing**: gap 8-14px giữa khối, padding card 11-18px
- **Mật độ**: dày đặc (dense) — hàng bảng cao ~8-9px padding, nhiều cột số liệu trên 1 dòng

## Interactions & Behavior
- **Tenant scope**: chọn tenant ở header lọc TẤT CẢ dữ liệu app theo tenant đó + con của nó (không hiện dữ liệu tenant khác)
- **Thanh toán mua thêm data**: 2 bước bắt buộc — chọn gói GB → modal xác nhận thanh toán → chỉ cộng GB sau khi bấm nút thanh toán (không cộng khi vừa chọn)
- **Checkbox trong bảng**: click vào checkbox không mở trang chi tiết (stopPropagation); click vào tên/dòng mới mở chi tiết
- **Modal**: overlay `rgba(15,20,23,.45)`, card trắng radius 10px, đóng bằng nút ✕ hoặc Huỷ
- **Phân trang**: client-side, số trang tính từ danyh sách đã lọc theo scope/filter hiện tại; nút ←/→ đổi màu xám khi ở đầu/cuối
- **Bảng full-height**: header lọc + phân trang cố định (flex:none), phần bảng giữa overflow-y:auto riêng, header cột sticky top:0

## Assets
Không dùng ảnh/icon ngoài — toàn bộ icon là hình học CSS đơn giản (dot, khung vuông bo góc). Font tải từ Google Fonts (IBM Plex Sans/Mono).

## Files
- `MikroTik Manager.dc.html` — toàn bộ thiết kế, 1 file, dữ liệu mock nằm trong logic JS (mảng `ROUTERS`, `PACKAGES`, `USERS`, `TENANTS`, `ADMINS`, `ZT_NETS`, `ZT_MEMBERS`...). Điều hướng bằng state `screen` trong component, không dùng router/URL thật.
